This is just to explain the name.

I wasn't planning on making a web browser when I first started the project in visual studio, I was just going to mess about but the idea of a browser came to mind.
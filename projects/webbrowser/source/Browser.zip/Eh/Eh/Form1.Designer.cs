﻿namespace Eh
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.webBrowser1 = new System.Windows.Forms.WebBrowser();
            this.URL = new System.Windows.Forms.TextBox();
            this.Home = new System.Windows.Forms.Button();
            this.Forward = new System.Windows.Forms.Button();
            this.Stop = new System.Windows.Forms.Button();
            this.Go = new System.Windows.Forms.Button();
            this.Refresh = new System.Windows.Forms.Button();
            this.Back = new System.Windows.Forms.Button();
            this.help = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // webBrowser1
            // 
            this.webBrowser1.Location = new System.Drawing.Point(-3, 29);
            this.webBrowser1.MinimumSize = new System.Drawing.Size(20, 20);
            this.webBrowser1.Name = "webBrowser1";
            this.webBrowser1.Size = new System.Drawing.Size(1013, 476);
            this.webBrowser1.TabIndex = 0;
            // 
            // URL
            // 
            this.URL.Location = new System.Drawing.Point(12, 4);
            this.URL.Name = "URL";
            this.URL.Size = new System.Drawing.Size(246, 20);
            this.URL.TabIndex = 1;
            this.URL.TextChanged += new System.EventHandler(this.URL_TextChanged);
            // 
            // Home
            // 
            this.Home.Location = new System.Drawing.Point(333, 4);
            this.Home.Name = "Home";
            this.Home.Size = new System.Drawing.Size(63, 23);
            this.Home.TabIndex = 3;
            this.Home.Text = "Home";
            this.Home.UseVisualStyleBackColor = true;
            this.Home.Click += new System.EventHandler(this.Home_Click);
            // 
            // Forward
            // 
            this.Forward.Location = new System.Drawing.Point(483, 4);
            this.Forward.Name = "Forward";
            this.Forward.Size = new System.Drawing.Size(75, 23);
            this.Forward.TabIndex = 5;
            this.Forward.Text = "Forward";
            this.Forward.UseVisualStyleBackColor = true;
            this.Forward.Click += new System.EventHandler(this.Forward_Click);
            // 
            // Stop
            // 
            this.Stop.Location = new System.Drawing.Point(645, 4);
            this.Stop.Name = "Stop";
            this.Stop.Size = new System.Drawing.Size(75, 23);
            this.Stop.TabIndex = 7;
            this.Stop.Text = "Stop";
            this.Stop.UseVisualStyleBackColor = true;
            this.Stop.Click += new System.EventHandler(this.Stop_Click);
            // 
            // Go
            // 
            this.Go.Location = new System.Drawing.Point(264, 4);
            this.Go.Name = "Go";
            this.Go.Size = new System.Drawing.Size(63, 23);
            this.Go.TabIndex = 8;
            this.Go.Text = "Go";
            this.Go.UseVisualStyleBackColor = true;
            this.Go.Click += new System.EventHandler(this.Go_Click);
            // 
            // Refresh
            // 
            this.Refresh.Location = new System.Drawing.Point(564, 4);
            this.Refresh.Name = "Refresh";
            this.Refresh.Size = new System.Drawing.Size(75, 23);
            this.Refresh.TabIndex = 9;
            this.Refresh.Text = "Refresh";
            this.Refresh.UseVisualStyleBackColor = true;
            this.Refresh.Click += new System.EventHandler(this.Refresh_Click_1);
            // 
            // Back
            // 
            this.Back.Location = new System.Drawing.Point(402, 4);
            this.Back.Name = "Back";
            this.Back.Size = new System.Drawing.Size(75, 23);
            this.Back.TabIndex = 10;
            this.Back.Text = "Back";
            this.Back.UseVisualStyleBackColor = true;
            this.Back.Click += new System.EventHandler(this.Back_Click);
            // 
            // help
            // 
            this.help.Location = new System.Drawing.Point(925, 4);
            this.help.Name = "help";
            this.help.Size = new System.Drawing.Size(75, 23);
            this.help.TabIndex = 11;
            this.help.Text = "Help";
            this.help.UseVisualStyleBackColor = true;
            this.help.Click += new System.EventHandler(this.help_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1022, 517);
            this.Controls.Add(this.help);
            this.Controls.Add(this.Back);
            this.Controls.Add(this.Refresh);
            this.Controls.Add(this.Go);
            this.Controls.Add(this.Stop);
            this.Controls.Add(this.Forward);
            this.Controls.Add(this.Home);
            this.Controls.Add(this.URL);
            this.Controls.Add(this.webBrowser1);
            this.Name = "Form1";
            this.Text = "Web Browser";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.WebBrowser webBrowser1;
        private System.Windows.Forms.TextBox URL;
        private System.Windows.Forms.Button Home;
        private System.Windows.Forms.Button Forward;
        private System.Windows.Forms.Button Stop;
        private System.Windows.Forms.Button Go;
        private System.Windows.Forms.Button Refresh;
        private System.Windows.Forms.Button Back;
        private System.Windows.Forms.Button help;
    }
}


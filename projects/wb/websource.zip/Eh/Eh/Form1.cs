﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Eh
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void webBrowser1_DocumentCompleted(object sender, WebBrowserDocumentCompletedEventArgs e)
        {

        }

  

        private void Home_Click(object sender, EventArgs e)
        {
            webBrowser1.GoHome();
        }

        private void Forward_Click(object sender, EventArgs e)
        {
            if (webBrowser1.CanGoForward)
            {
                webBrowser1.GoForward();
            }
        }

        private void Stop_Click(object sender, EventArgs e)
        {
            webBrowser1.Stop();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void Refresh_Click_1(object sender, EventArgs e)
        {
            webBrowser1.Refresh();
        }

        private void Back_Click(object sender, EventArgs e)
        {
            if (webBrowser1.CanGoBack)
            {
                webBrowser1.GoBack();
            }
        }

        private void Go_Click(object sender, EventArgs e)
        {
            string WebPage = URL.Text.Trim();
            webBrowser1.Navigate(WebPage);
        }

        private void URL_TextChanged(object sender, EventArgs e)
        {
            
        }

        private void help_Click(object sender, EventArgs e)
        {
            MessageBox.Show("This obiously isn't a fully fledged browser, it uses the IE framework and doesn't suppport fullscreen because I don't know how to do that. Have fun! Sauce at hyptex.cf [Requires Visual Studio]");
        }
    }
}
